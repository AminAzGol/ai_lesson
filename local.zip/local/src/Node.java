import java.util.ArrayList;

public class Node {
    ArrayList<Tank> tanks;

    public Node(){
        tanks = new ArrayList<>();
    }

}
