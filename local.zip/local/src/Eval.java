import java.util.ArrayList;

public class Eval {
    public int eval(Node node){
        int cost = 0;
        ArrayList<Tank> tanks = node.tanks;
        for(int i =0; i < tanks.size(); i++){
            cost += 1; // les tanks better answer
            Tank tank = tanks.get(i);
            for(Chemical chem: tank.chemicals){

        }

        return cost;
    }
}
