import java.util.ArrayList;

public class Tank {
    ArrayList<Chemical> chemicals;

    @Override
    public String toString() {
        String s = "";

        for(Chemical chem: chemicals){
            s += chem.name;
            if(chemicals.indexOf(chem) != chemicals.size() - 1)
                s += ',';
        }

        return s;
    }
}
